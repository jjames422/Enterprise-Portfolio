## Logical Data Model
Describe entities and relationships for the cloud platform.