## BPMN Processes
This section includes process models for business workflows.