# TOGAF Cloud Enterprise Architecture
This repository outlines the enterprise architecture for a modern cloud-based platform using TOGAF ADM.