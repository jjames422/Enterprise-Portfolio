## Security Reference Model
- IAM Policies
- Encryption Standards
- Firewall Rules